<?php

namespace App\Http\Controllers\API\Organization;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OrgTrainingUser extends Controller
{
    //
}
